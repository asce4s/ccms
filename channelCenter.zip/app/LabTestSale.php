<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LabTestSale extends Model
{
    protected $table = 'labtestsale';
}

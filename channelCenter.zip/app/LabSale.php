<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LabSale extends Model
{
    protected $table = 'labsale';
}
